package com.ieseljust.socialnetwork;

import com.ieseljust.DAO.EquipoDAO;
import com.ieseljust.DAO.JugadorsDAO;
import com.ieseljust.DAO.PosicionDAO;
import com.ieseljust.DAO.PresidentDAO;
import com.ieseljust.ORM.HibernateUtil;
import com.ieseljust.Model.Equipo;
import com.ieseljust.Model.Jugador;
import com.ieseljust.Model.Posicion;
import com.ieseljust.Model.President;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ivan
 */
public class Socialnetwork {

    private static void displayPage(JugadorsDAO jugadorsDAO, int pageNumber, int pageSize) {
        List<Jugador> jugadores = jugadorsDAO.selectAll(pageNumber, pageSize);

        if (jugadores != null) {
            System.out.println("Page " + pageNumber + " of " + calculateTotalPages(jugadorsDAO, pageSize));
            for (Jugador jugador : jugadores) {
                System.out.println(jugador);
            }
        } else {
            System.out.println("Error retrieving Jugadores.");
        }
    }

    private static int calculateTotalPages(JugadorsDAO jugadorsDAO, int pageSize) {
        List<Jugador> allJugadores = jugadorsDAO.selectAll(1, Integer.MAX_VALUE);
        return (int) Math.ceil((double) allJugadores.size() / pageSize);
    }

    public static void main(String[] args) {
        Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession();
//        SessionFactory sessionFactory = new Configuration().configure(new File("hibernate.cfg.xml")).addAnnotatedClass(Users.class).buildSessionFactory();
//        Session laSesion = sessionFactory.getCurrentSession();

        Transaction transaction = laSesion.beginTransaction();

        JugadorsDAO jugadorsDAO = new JugadorsDAO();

        int pageSize = 12;
        int currentPage = 1;

        displayPage(jugadorsDAO, currentPage, pageSize);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Enter option: <S> next, <A> previous, <G n> go to n, <Q> quit");
            String option = scanner.nextLine().toUpperCase();

            switch (option) {
                case "S":
                    currentPage++;
                    break;
                case "A":
                    currentPage = Math.max(1, currentPage - 1);
                    break;
                case "Q":
                    System.out.println("Exiting program.");
                    System.exit(0);
                default:
                    if (option.startsWith("G ")) {
                        try {
                            currentPage = Integer.parseInt(option.substring(2));
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input. Please enter a valid page number.");
                        }
                    } else {
                        System.out.println("Invalid option. Please enter a valid option.");
                    }
                    break;
            }

            displayPage(jugadorsDAO, currentPage, pageSize);
        }
    

    /**
     * Equipo eq1 = new Equipo("Barcelona"); laSesion.save(eq1); Jugador j1 =
     * new Jugador("messi", "DL"); laSesion.save(j1); Posicion p1 = new
     * Posicion( "DL"); Posicion p2 = new Posicion("MC"); laSesion.save(p1);
     * laSesion.save(p2); President pre1 = new President("laporte");
     * laSesion.save(pre1); laSesion.getTransaction().commit();
     *
     * PosicionDAO posicionDAO = new PosicionDAO(); if (args.length == 0) {
     * System.out.println("Usage: java PosicionDAO show [-r]"); return; } if
     * ("show".equals(args[0])) { boolean recursively = false;
     *
     * if (args.length > 1 && "-r".equals(args[1])) { recursively = true; }
     * posicionDAO.showPosicion(recursively); } else {
     * System.out.println("Unknow command: "+ args[0]); }
     *
     * EquipoDAO EquipoDAO = new EquipoDAO();
     *
     * if (args.length > 0 && "-r".equals(args[0])) {
     * EquipoDAO.insertEquipo(eq1); } else { posicionDAO.insertPosicion(p1); }
*
     */
    /**
     * //insert EquipoDAO dao = new EquipoDAO(); Equipo eq1 = new
     * Equipo("Barcelona"); Equipo eq2 = new Equipo(); eq2.setNombre("Madrid");
     * dao.insertEquipo(eq1);
     *
     * //delete
     *
     * Equipo eq3 = new Equipo(); eq3.setId(1); dao.deleteEquipo(eq3);
     *
     *
     * //update
     *
     * dao.updateEquipo(1); dao.selectAll();
     *
     *
     */
    }
}

