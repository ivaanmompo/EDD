package com.ieseljust.DAO;

import com.ieseljust.ORM.HibernateUtil;
import com.ieseljust.Model.Jugador;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;

public class JugadorsDAO {

    Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession();

    public JugadorsDAO() {
    }

    // Insert
    public void insertJugador(Jugador Jugador) {
        try {
            laSesion.getTransaction().begin();
            laSesion.save(Jugador);
            laSesion.getTransaction().commit();
            System.out.println("Jugador inserted correctly");
        } catch (Exception e) {
            laSesion.getTransaction().rollback();
            System.out.println("Error inserting Jugador. " + e.getMessage());
        } finally {
            laSesion.close();
        }
    }

    // Delete
    public void deleteJugador(Jugador Jugador) {
        try {
            laSesion.getTransaction().begin();
            laSesion.delete(Jugador);
            laSesion.getTransaction().commit();
            System.out.println("Jugador deleted correctly");
        } catch (Exception e) {
            if (laSesion.getTransaction() != null) {
                laSesion.getTransaction().rollback();
            }
            System.out.println("Error deleting Jugador. " + e.getMessage());
        } finally {
            laSesion.close();
        }
    }

    // Update
    public void updateJugador(int id) {
        try {
            laSesion.getTransaction().begin();

            Jugador jugadortoupdate = laSesion.get(Jugador.class, id);

            jugadortoupdate.setNombre("messi");
            jugadortoupdate.setPosicion("DEL");

            laSesion.saveOrUpdate(jugadortoupdate);

            laSesion.getTransaction().commit();

            System.out.println("Jugador updated correctly");
        } catch (Exception e) {
            if (laSesion.getTransaction() != null) {
                laSesion.getTransaction().rollback();
            }
            System.out.println("Error updating Jugador. " + e.getMessage());
        } finally {
            laSesion.close();
        }
    }

    // Select all jugadores paginated
    public List<Jugador> selectAll(int pageNumber, int pageSize) {
        try {
            laSesion.getTransaction().begin();

            Query<Jugador> query = laSesion.createQuery("FROM Jugador", Jugador.class);
            query.setFirstResult((pageNumber - 1) * pageSize);
            query.setMaxResults(pageSize);
            List<Jugador> jugadores = query.getResultList();

            laSesion.getTransaction().commit();

            return jugadores;
        } catch (Exception e) {
            if (laSesion.getTransaction() != null) {
                laSesion.getTransaction().rollback();
            }
            System.out.println("Error selecting Jugadores. " + e.getMessage());
            return null;
        } finally {
            laSesion.close();
        }
    }
}
